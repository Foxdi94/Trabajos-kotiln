package com.example.practica2

import android.media.MediaPlayer
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import kotlinx.android.synthetic.main.fragment_main.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentMain.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentMain : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    class Avatars (name : String, content : String, image : Int, music : Int) {
        var Name = name
        var Content = content
        var Image = image
        var Music = music

    }




    //val array_of_avatars = arrayListOf<Avatars>(avatar1,avatar2,avatar3,avatar4,avatar5)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var global_counter = 0
        val arrayMusic = arrayListOf<Int>(R.raw.sonido1, R.raw.sonido2,R.raw.sonido3,R.raw.sonido4,R.raw.sonido5)
        val v = inflater.inflate(R.layout.fragment_main, container, false)
        val btnPrev = v.findViewById<View>(R.id.btn_more_information) as Button
        btnPrev.setOnClickListener {
            if (global_counter!= 0)
                MediaPlayer.create(requireContext(), arrayMusic[global_counter - 1]).start()
            else
                MediaPlayer.create(requireContext(), arrayMusic[global_counter]).start()
            openFragment()
            val fragment = FragmentDetail()
            val fragmentManager = requireActivity().supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragmentContainerView, fragment)
            fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()

        }




            val avatar1 = Avatars ("carro cheems", "Hay destimos peores que la muerte", R.drawable.carscificcion, R.raw.sonido1)
            val avatar2 = Avatars ("sus", "No soy yo creanme", R.drawable.sus, R.raw.sonido2)
            val avatar3 = Avatars ("Ranchonorlax", "Arremangese padrimo", R.drawable.pokerancho, R.raw.sonido3)
            val avatar4 = Avatars ("El perrosexo", "unque no lo crea este es el creador del sexo", R.drawable.perrosexo, R.raw.sonido4)
            val avatar5 = Avatars ("El alfa", "El mejor compañero para todas tus transacciones", R.drawable.alfa, R.raw.sonido5)

            val array_img_source:ArrayList<Avatars> = arrayListOf<Avatars>()

            array_img_source.add(avatar1)
            array_img_source.add(avatar2)
            array_img_source.add(avatar3)
            array_img_source.add(avatar4)
            array_img_source.add(avatar5)

            val btn_arrow_left = v.findViewById<ImageView>(R.id.btn_arrow_left)
            val btn_arrow_right = v.findViewById<ImageView>(R.id.btn_arrow_rigth)
            val img_more_information = v.findViewById<Button>(R.id.btn_more_information)
            val img_big = v.findViewById<ImageView>(R.id.imageViewBig)
            //img_more_information.setImageResource(R.mipmap.carscificcion)
            btn_arrow_left.setOnClickListener {



                if (global_counter == 0) {
                    img_big.setImageResource(array_img_source[0].Image)
                    MediaPlayer.create(requireContext(), array_img_source[0].Music).start()
                } else if (global_counter == 1) {
                    img_big.setImageResource(array_img_source[1].Image)
                    MediaPlayer.create(requireContext(), array_img_source[1].Music).start()
                } else if (global_counter == 2) {
                    img_big.setImageResource(array_img_source[2].Image)
                    MediaPlayer.create(requireContext(), array_img_source[2].Music).start()
                } else if (global_counter == 3) {
                    img_big.setImageResource(array_img_source[3].Image)
                    MediaPlayer.create(requireContext(), array_img_source[3].Music).start()
                } else if (global_counter == 4) {
                    img_big.setImageResource(array_img_source[4].Image)
                    MediaPlayer.create(requireContext(), array_img_source[4].Music).start()
                } else if (global_counter <= 0){
                    global_counter = 4
                }
                global_counter--
                println(global_counter)
            }

            btn_arrow_right.setOnClickListener {




                if (global_counter == 0) {
                    img_big.setImageResource(array_img_source[0].Image)
                    MediaPlayer.create(requireContext(), array_img_source[0].Music).start()
                } else if (global_counter == 1) {
                    img_big.setImageResource(array_img_source[1].Image)
                    MediaPlayer.create(requireContext(), array_img_source[1].Music).start()
                } else if (global_counter == 2) {
                    img_big.setImageResource(array_img_source[2].Image)
                    MediaPlayer.create(requireContext(), array_img_source[2].Music).start()
                } else if (global_counter == 3) {
                    img_big.setImageResource(array_img_source[3].Image)
                    MediaPlayer.create(requireContext(), array_img_source[3].Music).start()
                } else if (global_counter == 4) {
                    img_big.setImageResource(array_img_source[4].Image)
                    MediaPlayer.create(requireContext(), array_img_source[4].Music).start()
                } else if (global_counter >= 4){
                    global_counter = 0
                }
                global_counter++
                println(global_counter)
            }



            var like_cheked = false
            val img_like = v.findViewById<View>(R.id.img_heart_like) as ImageView

            img_like.setOnClickListener{
                if (!like_cheked){
                    like_cheked = true
                    img_like.setImageResource(R.drawable.heart)
                     //val mytost = Toast.makeText(this,"this is toast message",Toast.LENGTH_SHORT).show()
                }else{
                    like_cheked = false
                    img_like.setImageResource(R.drawable.emptyheart)
                }
            }




        return v

    }
    
    

    private fun openFragment() {

        var fragment = FragmentDetail()
        //FragmentTransaction

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentMain.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentMain().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}




