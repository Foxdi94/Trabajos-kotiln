package com.amalip.cocktailapp.presentation.favorites

import androidx.lifecycle.ViewModel

class FavoriteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}