package com.amalip.cocktailapp.presentation.cocktails

/**
 * Created by Amalip on 9/29/2021.
 */
class CocktailFailure {
}