package com.amalip.cocktailapp.core.di

/**
 * Created by Amalip on 9/29/2021.
 */

object HelperModule {

}