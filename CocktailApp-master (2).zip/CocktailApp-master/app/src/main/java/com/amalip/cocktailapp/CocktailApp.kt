package com.amalip.cocktailapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Created by Amalip on 9/28/2021.
 */

@HiltAndroidApp
class CocktailApp : Application() {


}