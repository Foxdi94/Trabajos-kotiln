package com.amalip.cocktailapp.core.utils

/**
 * Created by Amalip on 10/4/2021.
 */

enum class LayoutType {

    LINEAR, GRID

}